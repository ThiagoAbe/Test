const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'http://localhost', //  URL da aplicação
    defaultCommandTimeout: 10000,
    requestTimeout: 10000,
    specPattern: 'cypress/integration/**/*.cy.js',
    video: true,
    screenshotOnRunFailure: true,
    viewportWidth: 2560, // Largura do monitor ultrawide
    viewportHeight: 1080, // Altura do monitor ultrawide
    setupNodeEvents(on, config) {
      // Configurações adicionais, se necessário
    },
  },
});