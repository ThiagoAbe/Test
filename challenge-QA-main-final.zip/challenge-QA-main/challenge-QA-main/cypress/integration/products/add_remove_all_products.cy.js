describe('Adicionar e Remover Todos os Produtos do Carrinho', () => {
    beforeEach(() => {
        cy.visit('/'); // Acessa a homepage da aplicação
    });

    it('deve adicionar todos os produtos ao carrinho e depois removê-los', () => {
        // Adiciona todos os produtos da página ao carrinho
        cy.get('#productsContainer > :nth-child(1) > button').click(); // Adiciona o primeiro produto
        cy.get('#productsContainer > :nth-child(2) > button').click(); // Adiciona o segundo produto
        cy.get('#productsContainer > :nth-child(3) > button').click(); // Adiciona o terceiro produto
        cy.get('#productsContainer > :nth-child(4) > button').click(); // Adiciona o quarto produto
        cy.get('#productsContainer > :nth-child(5) > button').click(); // Adiciona o quinto produto
        cy.get('#productsContainer > :nth-child(6) > button').click(); // Adiciona o sexto produto
        cy.get('#productsContainer > :nth-child(7) > button').click(); // Adiciona o sétimo produto
        cy.get('#productsContainer > :nth-child(8) > button').click(); // Adiciona o oitavo produto
        cy.get('#productsContainer > :nth-child(9) > button').click(); // Adiciona o nono produto
        cy.get('#productsContainer > :nth-child(10) > button').click(); // Adiciona o décimo produto

        // Abre o carrinho de compras
        cy.get('.cart').click(); // Acesse o carrinho de compras

        // Remove todos os produtos do carrinho
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o primeiro produto
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o próximo produto que agora está na posição 1
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o próximo produto que agora está na posição 1
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o próximo produto que agora está na posição 1
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o próximo produto que agora está na posição 1
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o próximo produto que agora está na posição 1
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o próximo produto que agora está na posição 1
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o próximo produto que agora está na posição 1
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o próximo produto que agora está na posição 1
        cy.get('#cartItems > :nth-child(1) > button').click(); // Remove o último produto

        // Verifica que o carrinho está vazio
        cy.get('.cart').should('not.contain', 'Camisa do Star Wars'); // Ajuste conforme o produto
        cy.get('.cart').should('not.contain', 'Action Figure do Homem-Aranha'); // Ajuste conforme o produto
        
    });
});
