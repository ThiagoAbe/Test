describe('Ordenar Produtos', () => {
    beforeEach(() => {
        cy.visit('/');
    });

    it('deve ordenar produtos por nome', () => {
        cy.get('#sortOrder').select('Nome (A-Z)');
        cy.get('#productsContainer > :nth-child(1)').find('span').should('contain', 'Action Figure do Homem-Aranha');
    });

    it('deve ordenar produtos por preço', () => {
        cy.get('#sortOrder').select('Preço (Menor para Maior)');
        cy.get('#productsContainer > :nth-child(1)')
            .should('contain', 'Adesivos do Marvel')
        cy.get('#productsContainer > :nth-child(10)')
            .should('contain', 'Mouse Pad da Mulher-Maravilha')

    });
});
