describe('Validação de Carregamento de Página', () => {
    beforeEach(() => {
        cy.visit('http://localhost'); // Substitua pela URL correta da sua aplicação se necessário
    });

    it('Deve carregar a primeira página de produtos por padrão', () => {
        // Verifica se o botão da página 1 está ativo ao carregar a aplicação
        cy.get('#pagination > :nth-child(1)').should('have.class', 'active');
        
        // Verifica se a lista de produtos está presente na página
        cy.get('.product-list').should('exist');
    });
});
