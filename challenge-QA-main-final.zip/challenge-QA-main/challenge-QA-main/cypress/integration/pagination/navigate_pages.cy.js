describe('Navegação e verificação de páginas', () => {
    beforeEach(() => {
      cy.visit('http://localhost'); // Substitua pela URL da sua aplicação
    });
  
    const verifyPageButton = (pageNumber, expectedActive, isSecondPart = false) => {
      const selector = isSecondPart 
        ? `#pagination > :nth-child(${pageNumber - 5})`
        : `#pagination > :nth-child(${pageNumber})`;
  
      if (expectedActive) {
        // Verifica se o botão da página atual tem a classe 'active'
        cy.get('.active').should('exist');
      } else {
        // Verifica se o botão da página não tem a classe 'active'
        cy.get(selector).should('not.have.class', 'active');
      }
    };
  
    const navigatePages6To10 = () => {
      // Verifica a existência do botão "Anterior" e o botão ativo da página 6
      cy.get('#pagination > :nth-child(1)').should('exist'); // Botão "Anterior"
      verifyPageButton(6, true, true); // Página 6 deve ser a ativa
  
      // Navega e verifica as páginas de 6 a 10
      for (let page = 7; page <= 10; page++) {
        cy.get(`#pagination > :nth-child(${page - 5})`).click(); // Clica no botão da página correspondente
        cy.wait(2000); // Espera para garantir que a página foi carregada
        verifyPageButton(page, true, true); // Verifica se o botão da página atual está ativo
      }
  
      // Verifica a presença do botão "Próximo" após a última página
      cy.get('#pagination > :nth-child(7)').should('exist'); // Botão "Próximo"
    };
  
    it('Deve navegar por todas as páginas e verificar o botão ativo', () => {
      // Navega e verifica as páginas de 1 a 5
      for (let page = 1; page <= 5; page++) {
        verifyPageButton(page, page === 1); // A página inicial é sempre a ativa
        cy.get(`#pagination > :nth-child(${page})`).click(); // Clica no botão da página
        cy.wait(2000); // Espera para garantir que a página foi carregada
      }
  
      // Navega para a página 6 e verifica a existência do botão Anterior
      cy.get('#pagination > :nth-child(6)').click(); // Clica no botão "Próximo"
      cy.wait(2000); // Espera para garantir que a página foi carregada
      verifyPageButton(6, true, true); // Verifica se o botão da página 6 está ativo
      cy.get('#pagination > :nth-child(1)').should('exist'); // Verifica a existência do botão "Anterior"
  
      // Navega e verifica as páginas de 6 a 10
      navigatePages6To10();
    });
  });
  