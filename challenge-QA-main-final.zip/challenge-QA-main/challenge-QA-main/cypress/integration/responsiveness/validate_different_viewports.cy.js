describe('Alternar Entre Diferentes Visualizações (Mobile, Tablet e Desktop)', () => {
    beforeEach(() => {
        cy.visit('/'); // Acessa a página da aplicação
    });

    it('deve alternar entre visualizações Mobile, Tablet e Desktop', () => {
        // Visualização Mobile
        cy.viewport('iphone-6'); // Muda para visualização mobile
        cy.wait(1000); // Aguarda um segundo para garantir que a mudança foi aplicada

        // Visualização Tablet
        cy.viewport('ipad-2'); // Muda para visualização tablet
        cy.wait(1000); // Aguarda um segundo para garantir que a mudança foi aplicada

        // Visualização Desktop (Ultrawide)
        cy.viewport(2560, 1080); // Muda para visualização desktop
        cy.wait(1000); // Aguarda um segundo para garantir que a mudança foi aplicada
    });
});
