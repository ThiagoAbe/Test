describe('Testar Filtros de Categoria', () => {
    beforeEach(() => {
      // Visita a página inicial antes de cada teste
      cy.visit('http://localhost'); // Substitua pela URL da sua aplicação
    });
  
    it('Deve testar cada filtro de categoria disponível e validar a presença dos produtos', () => {
      // Define os filtros possíveis e os produtos esperados para cada filtro
      const filtros = {
        'all': [
          'Action Figure do Homem-Aranha',
          'Funko Pop! Darth Vader',
          'Camisa do Star Wars',
          'Camiseta do Batman',
          'Poster do Harry Potter',
          'Caneca do Senhor dos Anéis',
          'Luminária do Super Mario',
          'Caderno do Star Trek',
          'Quebra-Cabeça do Mapa da Terra Média',
          'Mouse Pad do League of Legends'
        ],
        'clothing': [
          'Camisa do Star Wars',
          'Camiseta do Batman'
        ],
        'decor': [
          'Luminária do Super Mario'
        ],
        'posters': [
          'Poster do Harry Potter'
        ],
        'toys': [
          'Action Figure do Homem-Aranha',
          'Funko Pop! Darth Vader'
        ],
        'bags': [
          // Adicione aqui os produtos que pertencem à categoria 'bags' se houver
        ],
        'puzzles': [
          'Quebra-Cabeça do Mapa da Terra Média'
        ],
        'mugs': [
          'Caneca do Senhor dos Anéis'
        ],
        'accessories': [
          // Adicione aqui os produtos que pertencem à categoria 'accessories' se houver
        ],
        'books': [
          // Adicione aqui os produtos que pertencem à categoria 'books' se houver
        ]
      };
  
      Object.keys(filtros).forEach(filtro => {
        // Seleciona o filtro na lista de categorias
        cy.get('#categoryFilter').select(filtro);
  
        // Verifica o resultado após a seleção do filtro
        cy.get('#productsContainer').should('exist'); // Verificar se o contêiner de produtos está visível
  
        // Verifica a presença dos produtos esperados
        filtros[filtro].forEach(produto => {
          cy.contains(produto).should('be.visible');
        });
  
        cy.wait(500); // Aguardar meio segundo
      });
    });
  });
  