describe('Filtrar por Faixa de Preço', () => {
    beforeEach(() => {
        cy.visit('/');
    });

    it('deve ordenar produtos do menor para o maior e depois do maior para o menor preço', () => {
        // Seleciona a opção "Preço (Menor para Maior)"
        cy.get('#sortOrder').select('priceAsc');
        
        // Aguarda a aplicação da ordenação
        cy.wait(500); // Ajuste o tempo de espera conforme necessário

        // Verifica se o primeiro item é "Adesivos do Marvel"
        cy.get('#productsContainer > :nth-child(1)').should('contain.text', 'Adesivos do Marvel');
        
        // Verifica se o décimo item é "Mouse Pad da Mulher-Maravilha"
        cy.get('#productsContainer > :nth-child(10)').should('contain.text', 'Mouse Pad da Mulher-Maravilha');

        // Seleciona a opção "Preço (Maior para Menor)"
        cy.get('#sortOrder').select('priceDesc');
        
        // Aguarda a aplicação da ordenação
        cy.wait(500); // Ajuste o tempo de espera conforme necessário

        // Verifica se o primeiro item é "Livro de RPG D&D"
        cy.get('#productsContainer > :nth-child(1)').should('contain.text', 'Livro de RPG D&D');
        
        // Verifica se o décimo item é "Quadro do Falcão"
        cy.get('#productsContainer > :nth-child(10)').should('contain.text', 'Quadro do Falcão');
    });
});
