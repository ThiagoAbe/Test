describe('Ativar Modo Escuro', () => {
    beforeEach(() => {
        cy.visit('/');
    });

    it('deve ativar o modo escuro', () => {
        // Clica no botão para ativar o modo escuro
        cy.get('#themeToggleBtn').click();

        // Aguarda um tempo para garantir que a mudança tenha sido aplicada
        cy.wait(500); // Ajuste o tempo se necessário

        // Verifica se o botão "Modo Escuro" ainda está visível após a ativação do modo escuro
        cy.get('#themeToggleBtn').should('be.visible');
    });
});
