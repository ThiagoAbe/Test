describe('Desativar Modo Escuro', () => {
    beforeEach(() => {
        cy.visit('/');
    });

    it('deve desativar o modo escuro', () => {
        // Primeiro clique para ativar o modo escuro
        cy.get('#themeToggleBtn').click();
        // Segundo clique para desativar o modo escuro
        cy.get('#themeToggleBtn').click();
        // Verifica se o modo escuro foi desativado
        cy.get('body').should('not.have.class', 'dark-mode');
    });
});
