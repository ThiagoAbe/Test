describe('Add Product to Cart', () => {
    beforeEach(() => {
        cy.visit('http://localhost'); // Certifique-se de que a URL está correta
    });

    it('should add a product to the cart and verify it was added correctly', () => {
        // Clica no botão de adicionar ao carrinho para o produto "Camisa do Star Wars"
        cy.get('#productsContainer > :nth-child(3) > button').click();

        // Verifica se o produto foi adicionado ao carrinho
        cy.get('.cart').should('exist'); // Verifica se o carrinho está visível
        cy.get('.cart-item').should('exist'); // Verifica se há um item no carrinho
        cy.get('.cart-item').should('have.length', 1); // Verifica se há exatamente um item no carrinho

        // Verifica se o produto correto foi adicionado ao carrinho
        cy.get('.cart-item > span').should('contain.text', 'Camisa do Star Wars'); // Verifica o nome do produto
    });
});
