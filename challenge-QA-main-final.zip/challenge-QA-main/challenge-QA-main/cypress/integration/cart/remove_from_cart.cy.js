describe('Adicionar e Remover Produtos do Carrinho', () => {
    beforeEach(() => {
        cy.visit('/');

        // Adiciona o primeiro produto ao carrinho (Action Figure do Homem-Aranha)
        cy.get('#productsContainer > :nth-child(1) > button').click();

        // Adiciona o segundo produto ao carrinho (Funko Pop! Darth Vader)
        cy.get('#productsContainer > :nth-child(2) > button').click();

    });

    it('deve remover todos os produtos do carrinho', () => {
        // Remove o primeiro produto do carrinho
        cy.get('#cartItems > :nth-child(1) > button').click();

        // Verifica se o carrinho está vazio
        cy.get('#cartItems > :nth-child(2)').should('not.exist');
    });
});
