describe('Adicionar Múltiplos Itens e Finalizar Compra', () => {
    beforeEach(() => {
        cy.visit('/');

        // Adiciona o produto "Poster do Harry Potter" ao carrinho 5 vezes
        for (let i = 0; i < 5; i++) {
            cy.get('#productsContainer > :nth-child(5) > button').click();
        }
    });

    it('deve adicionar 5 vezes o Poster do Harry Potter e finalizar a compra', () => {
        // Verifica se o produto foi adicionado 5 vezes (validação visual)
        cy.get('.cart-item').should('have.length', 5);

        // Clica no botão de finalizar compra
        cy.get('#finalizePurchaseLink > button').click();
    });
});
