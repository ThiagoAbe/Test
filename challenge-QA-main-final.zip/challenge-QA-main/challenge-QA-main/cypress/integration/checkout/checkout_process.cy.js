describe('Processo de Checkout', () => {
    beforeEach(() => {
        cy.visit('/');
        // Adiciona o produto "Action Figure do Homem-Aranha" ao carrinho
        cy.get('#productsContainer > :nth-child(1) > button').click();
        // Abre o carrinho de compras
        cy.get('.cart > h2').click(); // Corrigido para o seletor de carrinho correto
    });

    it('deve concluir o processo de checkout', () => {
        // Clica no botão de checkout
        cy.get('#finalizePurchaseLink > button').click();
        // Verifica se a URL foi atualizada para a página de checkout
        cy.url().should('include', '/checkout');
        cy.get('.checkout-button-confirm').click();
    });
});
