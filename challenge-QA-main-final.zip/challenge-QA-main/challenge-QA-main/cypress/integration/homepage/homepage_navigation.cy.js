describe('Navegação na Homepage', () => {
    beforeEach(() => {
        cy.visit('/');
    });

    it('deve navegar para a página de checkout ao clicar no botão "Finalizar Compra"', () => {
        // Clica no botão "Finalizar Compra"
        cy.get('button').contains('Finalizar Compra').click();
        // Verifica se a URL foi alterada para a página de checkout
        cy.url().should('include', '/checkout');
    });

    it('deve voltar para a homepage a partir da página de checkout', () => {
        // Clica no botão "Finalizar Compra" para navegar para a página de checkout
        cy.get('button').contains('Finalizar Compra').click();
        // Usa o seletor da homepage para voltar
        cy.get('button').contains('Cancelar').click(); 
        
    });
});
