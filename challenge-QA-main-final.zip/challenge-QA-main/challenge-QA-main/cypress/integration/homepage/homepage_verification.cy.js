describe('Homepage Verification', () => {
    beforeEach(() => {
      // Acesse a homepage sem especificar a porta
      cy.visit('http://localhost');
    });
  
    it('Deve verificar a presença dos elementos principais', () => {
      // Verifica a presença do título "Geek QA Gear"
      cy.get('h1').should('exist');
  
      // Verifica a presença do botão "Limpar"
      cy.get('#clearSearchBtn').should('exist');
  
      // Verifica a presença do campo de busca
      cy.get('#searchInput').should('exist');
  
      // Verifica a presença do botão de busca
      cy.get('[onclick="searchProducts()"]').should('exist');
  
      // Verifica a presença do botão "Modo Escuro"
      cy.get('#themeToggleBtn').should('exist');
  
      // Verifica a presença do texto "Filtros"
      cy.get('#themeToggleBtn').should('exist');
  
      // Verifica a presença do texto "Categoria"
      cy.get(':nth-child(2) > label').should('exist');
  
      // Verifica a presença do campo de seleção de categorias
      cy.get('#categoryFilter').should('exist');
  
      // Verifica a presença do texto "Ordenar por"
      cy.get('#categoryFilter').should('exist');
  
      // Verifica a presença do campo de seleção "Nome (A-Z)"
      cy.get('#sortOrder').should('exist');
  
      // Verifica a presença do texto "Carrinho de Compras"
      cy.get('.cart > h2').should('exist');
  
      // Verifica a presença do botão "Finalizar Compra"
      cy.get('#finalizePurchaseLink > button').should('exist');
    });
  });
  