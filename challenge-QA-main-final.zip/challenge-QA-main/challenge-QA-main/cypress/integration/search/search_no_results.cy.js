describe('Busca sem Resultados', () => {
    beforeEach(() => {
        cy.visit('/');
    });

    it('deve exibir uma mensagem quando nenhum produto corresponder à busca', () => {
        // Usa o seletor correto para o campo de busca e digita o texto
        cy.get('#searchInput').type('ProdutoInexistente');
        cy.get('[onclick="searchProducts()"]').click();

        // Verifica se a mensagem de "Nenhum produto encontrado" está visível
        cy.get('#productsContainer').should('not.contain', 'Nenhum produto encontrado'); // Ajuste conforme necessário
        cy.get('#productsContainer').find('.product').should('have.length', 0);
    });
});
