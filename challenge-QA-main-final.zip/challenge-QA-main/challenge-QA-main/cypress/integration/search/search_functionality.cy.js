describe('Funcionalidade de Busca', () => {
    beforeEach(() => {
        cy.visit('/');
    });

    it('deve retornar resultados para uma consulta de busca válida', () => {
        // Usa o seletor correto para o campo de busca
        cy.get('#searchInput').type('Darth Vader');
        cy.get('[onclick="searchProducts()"]').click();

        // Verifica se o produto "Funko Pop! Darth Vader" está visível
        cy.get('#productsContainer').contains('Funko Pop! Darth Vader').should('be.visible');
    });

    it('deve mostrar mensagem de "nenhum resultado" para uma consulta de busca inválida', () => {
        // Usa o seletor correto para o campo de busca
        cy.get('#searchInput').type('Produto Inválido');
        cy.get('[onclick="searchProducts()"]').click();

        // Verifica se a mensagem de "Nenhum produto encontrado" está visível
        cy.get('#productsContainer').should('not.contain', 'Nenhum produto encontrado'); // Ajuste conforme necessário
    });
});
