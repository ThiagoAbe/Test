describe('Busca com Caracteres Especiais', () => {
    beforeEach(() => {
        cy.visit('/');
    });

    it('deve lidar com consultas de busca com caracteres especiais e buscar um produto existente', () => {
        // Usa o seletor correto para o campo de busca e digita o texto com caracteres especiais
        cy.get('#searchInput').type('Star Wars @#%');
        cy.get('[onclick="searchProducts()"]').click();

        // Verifica que a lista de produtos não contém a mensagem de "Nenhum produto encontrado"
        cy.get('#productsContainer').should('exist'); // Verifica se o contêiner de produtos está presente

        // Limpa o campo de busca
        cy.get('#searchInput').clear();

        // Busca um produto que realmente exista
        cy.get('#searchInput').type('Camisa do Star Wars');
        cy.get('[onclick="searchProducts()"]').click();

        // Verifica se o produto específico "Camisa do Star Wars" está visível
        cy.get('#productsContainer').find('span').contains('Camisa do Star Wars').should('be.visible');
    });
});
