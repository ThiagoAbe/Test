let currentPage = 1;
const productsPerPage = 10;
const pagesPerBlock = 5
let currentSort = 'name'; // Critério de ordenação inicial
let sortOrder = 'asc'; 

// Lista de produtos (substitua com seus produtos reais)
const products = [
    { id: 1, name: "Action Figure do Homem-Aranha", category: "toys", price: 49.99 },
    { id: 2, name: "Funko Pop! Darth Vader", category: "toys", price: 39.99 },
    { id: 3, name: "Camisa do Star Wars", category: "clothing", price: 29.99 },
    { id: 4, name: "Camiseta do Batman", category: "clothing", price: 34.99 },
    { id: 5, name: "Poster do Harry Potter", category: "posters", price: 19.99 },
    { id: 6, name: "Caneca do Senhor dos Anéis", category: "mugs", price: 24.99 },
    { id: 7, name: "Luminária do Super Mario", category: "decor", price: 59.99 },
    { id: 8, name: "Caderno do Star Trek", category: "stationery", price: 14.99 },
    { id: 9, name: "Quebra-Cabeça do Mapa da Terra Média", category: "puzzles", price: 39.99 },
    { id: 10, name: "Mouse Pad do League of Legends", category: "accessories", price: 18.99 },
    { id: 11, name: "Bolsa do Rick and Morty", category: "bags", price: 44.99 },
    { id: 12, name: "Figurine do Goku", category: "toys", price: 54.99 },
    { id: 13, name: "Livro de RPG D&D", category: "books", price: 89.99 },
    { id: 14, name: "Action Figure do Deadpool", category: "toys", price: 59.99 },
    { id: 15, name: "Camiseta do Star Trek", category: "clothing", price: 29.99 },
    { id: 16, name: "Caneca do Doctor Who", category: "mugs", price: 21.99 },
    { id: 17, name: "Adesivos do Marvel", category: "accessories", price: 9.99 },
    { id: 18, name: "Posters do Avengers", category: "posters", price: 24.99 },
    { id: 19, name: "Luminária do Star Wars", category: "decor", price: 49.99 },
    { id: 20, name: "Agenda do Harry Potter", category: "stationery", price: 29.99 },
    { id: 21, name: "Camiseta do Game of Thrones", category: "clothing", price: 34.99 },
    { id: 22, name: "Funko Pop! Iron Man", category: "toys", price: 39.99 },
    { id: 23, name: "Bloco de Notas do Batman", category: "stationery", price: 12.99 },
    { id: 24, name: "Quadro do Stranger Things", category: "decor", price: 64.99 },
    { id: 25, name: "Action Figure do Pikachu", category: "toys", price: 49.99 },
    { id: 26, name: "Camiseta do Star Wars", category: "clothing", price: 27.99 },
    { id: 27, name: "Poster do Marvel", category: "posters", price: 18.99 },
    { id: 28, name: "Caneca do Star Trek", category: "mugs", price: 22.99 },
    { id: 29, name: "Bolsa do Harry Potter", category: "bags", price: 39.99 },
    { id: 30, name: "Quebra-Cabeça do Star Wars", category: "puzzles", price: 35.99 },
    { id: 31, name: "Figurine do Thor", category: "toys", price: 64.99 },
    { id: 32, name: "Luminária do Doctor Who", category: "decor", price: 49.99 },
    { id: 33, name: "Mouse Pad do Batman", category: "accessories", price: 16.99 },
    { id: 34, name: "Caderno do Rick and Morty", category: "stationery", price: 17.99 },
    { id: 35, name: "Figurine do Harry Potter", category: "toys", price: 59.99 },
    { id: 36, name: "Bolsa do Stranger Things", category: "bags", price: 44.99 },
    { id: 37, name: "Posters do Game of Thrones", category: "posters", price: 29.99 },
    { id: 38, name: "Caneca do League of Legends", category: "mugs", price: 24.99 },
    { id: 39, name: "Camiseta do Avengers", category: "clothing", price: 32.99 },
    { id: 40, name: "Figurine do Luke Skywalker", category: "toys", price: 54.99 },
    { id: 41, name: "Caderno do Avengers", category: "stationery", price: 21.99 },
    { id: 42, name: "Quadro do Marvel", category: "decor", price: 59.99 },
    { id: 43, name: "Mouse Pad do Star Trek", category: "accessories", price: 19.99 },
    { id: 44, name: "Luminária do Pikachu", category: "decor", price: 45.99 },
    { id: 45, name: "Bloco de Notas do Star Wars", category: "stationery", price: 14.99 },
    { id: 46, name: "Caneca do Avengers", category: "mugs", price: 23.99 },
    { id: 47, name: "Posters do Doctor Who", category: "posters", price: 21.99 },
    { id: 48, name: "Bolsa do Marvel", category: "bags", price: 37.99 },
    { id: 49, name: "Camiseta do Pikachu", category: "clothing", price: 28.99 },
    { id: 50, name: "Action Figure do Super Mario", category: "toys", price: 49.99 },
    { id: 51, name: "Quebra-Cabeça do Castelo de Hogwarts", category: "puzzles", price: 45.99 },
    { id: 52, name: "Quebra-Cabeça do Trono de Ferro", category: "puzzles", price: 49.99 },
    { id: 53, name: "Quebra-Cabeça do Millennium Falcon", category: "puzzles", price: 39.99 },
    { id: 54, name: "Quebra-Cabeça do Mapa do Maroto", category: "puzzles", price: 44.99 },
    { id: 55, name: "Quebra-Cabeça da Fortaleza Vermelha", category: "puzzles", price: 42.99 },
    { id: 56, name: "Quebra-Cabeça do Hogwarts Express", category: "puzzles", price: 46.99 },
    { id: 57, name: "Quebra-Cabeça do Castelo da Disney", category: "puzzles", price: 50.99 },
    { id: 58, name: "Quebra-Cabeça do Taj Mahal", category: "puzzles", price: 48.99 },
    { id: 59, name: "Quebra-Cabeça do Coliseu", category: "puzzles", price: 47.99 },
    { id: 60, name: "Quebra-Cabeça da Torre Eiffel", category: "puzzles", price: 45.99 },
    { id: 61, name: "Quebra-Cabeça do Nautilus", category: "puzzles", price: 49.99 },
    { id: 62, name: "Quebra-Cabeça do DeLorean", category: "puzzles", price: 43.99 },
    { id: 63, name: "Quebra-Cabeça do Palácio de Buckingham", category: "puzzles", price: 46.99 },
    { id: 64, name: "Quebra-Cabeça do Museu do Louvre", category: "puzzles", price: 47.99 },
    { id: 65, name: "Quebra-Cabeça do Big Ben", category: "puzzles", price: 44.99 },
    { id: 66, name: "Action Figure do Hulk", category: "toys", price: 59.99 },
    { id: 67, name: "Action Figure do Thanos", category: "toys", price: 64.99 },
    { id: 68, name: "Action Figure do Capitão América", category: "toys", price: 54.99 },
    { id: 69, name: "Action Figure do Homem de Ferro", category: "toys", price: 64.99 },
    { id: 70, name: "Action Figure do Wolverine", category: "toys", price: 58.99 },
    { id: 71, name: "Action Figure do Superman", category: "toys", price: 63.99 },
    { id: 72, name: "Action Figure da Mulher-Maravilha", category: "toys", price: 59.99 },
    { id: 73, name: "Action Figure do Thor", category: "toys", price: 64.99 },
    { id: 74, name: "Action Figure do Flash", category: "toys", price: 57.99 },
    { id: 75, name: "Action Figure do Aquaman", category: "toys", price: 62.99 },
    { id: 76, name: "Action Figure do Green Lantern", category: "toys", price: 55.99 },
    { id: 77, name: "Action Figure da Viúva Negra", category: "toys", price: 61.99 },
    { id: 78, name: "Quadro do Batman", category: "decor", price: 69.99 },
    { id: 79, name: "Quadro do Superman", category: "decor", price: 59.99 },
    { id: 80, name: "Quadro do Mulher-Maravilha", category: "decor", price: 64.99 },
    { id: 81, name: "Quadro do Flash", category: "decor", price: 59.99 },
    { id: 82, name: "Quadro do Aquaman", category: "decor", price: 69.99 },
    { id: 83, name: "Quadro do Lanterna Verde", category: "decor", price: 64.99 },
    { id: 84, name: "Quadro do Coringa", category: "decor", price: 69.99 },
    { id: 85, name: "Quadro do Arlequina", category: "decor", price: 64.99 },
    { id: 86, name: "Quadro do Homem de Ferro", category: "decor", price: 69.99 },
    { id: 87, name: "Quadro do Capitão América", category: "decor", price: 64.99 },
    { id: 88, name: "Quadro do Thor", category: "decor", price: 59.99 },
    { id: 89, name: "Quadro do Hulk", category: "decor", price: 69.99 },
    { id: 90, name: "Quadro do Wolverine", category: "decor", price: 64.99 },
    { id: 91, name: "Quadro do Deadpool", category: "decor", price: 59.99 },
    { id: 92, name: "Quadro do Homem-Aranha", category: "decor", price: 69.99 },
    { id: 93, name: "Quadro do Venom", category: "decor", price: 64.99 },
    { id: 94, name: "Quadro do Doutor Estranho", category: "decor", price: 69.99 },
    { id: 95, name: "Quadro do Pantera Negra", category: "decor", price: 64.99 },
    { id: 96, name: "Quadro do Loki", category: "decor", price: 69.99 },
    { id: 97, name: "Quadro do Gavião Arqueiro", category: "decor", price: 59.99 },
    { id: 98, name: "Quadro do Nick Fury", category: "decor", price: 64.99 },
    { id: 99, name: "Quadro do Falcão", category: "decor", price: 69.99 },
    { id: 100, name: "Camiseta do Superman", category: "clothing", price: 34.99 },
    { id: 101, name: "Camiseta do Batman", category: "clothing", price: 32.99 },
    { id: 102, name: "Camiseta da Mulher-Maravilha", category: "clothing", price: 35.99 },
    { id: 103, name: "Camiseta do Lanterna Verde", category: "clothing", price: 31.99 },
    { id: 104, name: "Camiseta do Flash", category: "clothing", price: 33.99 },
    { id: 105, name: "Camiseta do Coringa", category: "clothing", price: 34.99 },
    { id: 106, name: "Camiseta da Arlequina", category: "clothing", price: 32.99 },
    { id: 107, name: "Camiseta do Homem de Ferro", category: "clothing", price: 34.99 },
    { id: 108, name: "Camiseta do Capitão América", category: "clothing", price: 32.99 },
    { id: 109, name: "Camiseta do Thor", category: "clothing", price: 34.99 },
    { id: 110, name: "Camiseta do Hulk", category: "clothing", price: 35.99 },
    { id: 111, name: "Camiseta do Wolverine", category: "clothing", price: 31.99 },
    { id: 112, name: "Camiseta do Deadpool", category: "clothing", price: 33.99 },
    { id: 113, name: "Camiseta do Homem-Aranha", category: "clothing", price: 34.99 },
    { id: 114, name: "Camiseta do Venom", category: "clothing", price: 32.99 },
    { id: 115, name: "Camiseta do Doutor Estranho", category: "clothing", price: 34.99 },
    { id: 116, name: "Camiseta do Pantera Negra", category: "clothing", price: 35.99 },
    { id: 117, name: "Camiseta do Loki", category: "clothing", price: 31.99 },
    { id: 118, name: "Camiseta do Gavião Arqueiro", category: "clothing", price: 33.99 },
    { id: 119, name: "Camiseta do Nick Fury", category: "clothing", price: 34.99 },
    { id: 120, name: "Camiseta do Falcão", category: "clothing", price: 32.99 },
    { id: 121, name: "Camiseta do Groot", category: "clothing", price: 33.99 },
    { id: 122, name: "Camiseta do Rocket", category: "clothing", price: 32.99 },
    { id: 123, name: "Camiseta do Star-Lord", category: "clothing", price: 34.99 },
    { id: 124, name: "Camiseta do Drax", category: "clothing", price: 35.99 },
    { id: 125, name: "Camiseta da Gamora", category: "clothing", price: 34.99 },
    { id: 126, name: "Camiseta do Peter Quill", category: "clothing", price: 32.99 },
    { id: 127, name: "Camiseta do Yondu", category: "clothing", price: 33.99 },
    { id: 128, name: "Camiseta do Mantis", category: "clothing", price: 32.99 },
    { id: 129, name: "Camiseta do Nebula", category: "clothing", price: 34.99 },
    { id: 130, name: "Agenda do Batman", category: "stationery", price: 19.99 },
    { id: 131, name: "Agenda do Superman", category: "stationery", price: 18.99 },
    { id: 132, name: "Agenda da Mulher-Maravilha", category: "stationery", price: 19.99 },
    { id: 133, name: "Agenda do Lanterna Verde", category: "stationery", price: 17.99 },
    { id: 134, name: "Agenda do Flash", category: "stationery", price: 18.99 },
    { id: 135, name: "Agenda do Coringa", category: "stationery", price: 19.99 },
    { id: 136, name: "Agenda da Arlequina", category: "stationery", price: 18.99 },
    { id: 137, name: "Agenda do Homem de Ferro", category: "stationery", price: 19.99 },
    { id: 138, name: "Agenda do Capitão América", category: "stationery", price: 17.99 },
    { id: 139, name: "Agenda do Thor", category: "stationery", price: 19.99 },
    { id: 140, name: "Agenda do Hulk", category: "stationery", price: 18.99 },
    { id: 141, name: "Agenda do Wolverine", category: "stationery", price: 19.99 },
    { id: 142, name: "Agenda do Deadpool", category: "stationery", price: 18.99 },
    { id: 143, name: "Agenda do Homem-Aranha", category: "stationery", price: 19.99 },
    { id: 144, name: "Agenda do Pantera Negra", category: "stationery", price: 18.99 },
    { id: 145, name: "Agenda do Loki", category: "stationery", price: 19.99 },
    { id: 146, name: "Agenda do Doutor Estranho", category: "stationery", price: 18.99 },
    { id: 147, name: "Mouse Pad do Superman", category: "accessories", price: 12.99 },
    { id: 148, name: "Mouse Pad do Batman", category: "accessories", price: 11.99 },
    { id: 149, name: "Mouse Pad da Mulher-Maravilha", category: "accessories", price: 12.99 },
    { id: 150, name: "Mouse Pad do Lanterna Verde", category: "accessories", price: 10.99 },
    { id: 151, name: "Mouse Pad do Flash", category: "accessories", price: 11.99 },
    { id: 152, name: "Mouse Pad do Homem de Ferro", category: "accessories", price: 12.99 },
    { id: 153, name: "Mouse Pad do Capitão América", category: "accessories", price: 11.99 },
    { id: 154, name: "Mouse Pad do Hulk", category: "accessories", price: 12.99 },
    { id: 155, name: "Mouse Pad do Thor", category: "accessories", price: 10.99 },
    { id: 156, name: "Mouse Pad do Homem-Aranha", category: "accessories", price: 11.99 },
    { id: 157, name: "Caneca do Superman", category: "mugs", price: 15.99 },
    { id: 158, name: "Caneca do Batman", category: "mugs", price: 16.99 },
    { id: 159, name: "Caneca da Mulher-Maravilha", category: "mugs", price: 15.99 },
    { id: 160, name: "Caneca do Lanterna Verde", category: "mugs", price: 14.99 },
    { id: 161, name: "Caneca do Flash", category: "mugs", price: 16.99 },
    { id: 162, name: "Caneca do Homem de Ferro", category: "mugs", price: 15.99 },
    { id: 163, name: "Caneca do Capitão América", category: "mugs", price: 16.99 },
    { id: 164, name: "Caneca do Hulk", category: "mugs", price: 14.99 },
    { id: 165, name: "Caneca do Thor", category: "mugs", price: 15.99 },
    { id: 166, name: "Caneca do Homem-Aranha", category: "mugs", price: 16.99 },
    { id: 167, name: "Caneca do Deadpool", category: "mugs", price: 15.99 },
    { id: 168, name: "Figurine do Superman", category: "toys", price: 19.99 },
    { id: 169, name: "Figurine do Batman", category: "toys", price: 18.99 },
    { id: 170, name: "Figurine da Mulher-Maravilha", category: "toys", price: 19.99 },
    { id: 171, name: "Figurine do Lanterna Verde", category: "toys", price: 17.99 },
    { id: 172, name: "Figurine do Flash", category: "toys", price: 18.99 },
    { id: 173, name: "Figurine do Homem de Ferro", category: "toys", price: 19.99 },
    { id: 174, name: "Figurine do Capitão América", category: "toys", price: 17.99 },
    { id: 175, name: "Figurine do Thor", category: "toys", price: 19.99 },
    { id: 176, name: "Figurine do Hulk", category: "toys", price: 18.99 },
    { id: 177, name: "Figurine do Homem-Aranha", category: "toys", price: 19.99 },
    { id: 178, name: "Figurine do Deadpool", category: "toys", price: 17.99 },
    { id: 179, name: "Figurine do Loki", category: "toys", price: 19.99 },
    { id: 180, name: "Figurine do Pantera Negra", category: "toys", price: 18.99 },
    { id: 181, name: "Livro do Batman: Ano Um", category: "books", price: 22.99 },
    { id: 182, name: "Livro do Superman: Terra Um", category: "books", price: 21.99 },
    { id: 183, name: "Livro da Mulher-Maravilha: Sangue", category: "books", price: 23.99 },
    { id: 184, name: "Livro do Lanterna Verde: Renascimento", category: "books", price: 24.99 },
    { id: 185, name: "Livro do Flash: Renascimento", category: "books", price: 22.99 },
    { id: 186, name: "Livro do Homem de Ferro: Extremis", category: "books", price: 21.99 },
    { id: 187, name: "Livro do Capitão América: O Soldado Invernal", category: "books", price: 23.99 },
    { id: 188, name: "Livro do Thor: Ragnarok", category: "books", price: 24.99 },
    { id: 189, name: "Livro do Hulk: Planeta Hulk", category: "books", price: 22.99 },
    { id: 190, name: "Livro do Homem-Aranha: Azul", category: "books", price: 23.99 },
    { id: 191, name: "Livro do Deadpool: Guerra Civil", category: "books", price: 24.99 },
    { id: 192, name: "Livro do Loki: Agente de Asgard", category: "books", price: 21.99 },
    { id: 193, name: "Livro do Pantera Negra: Uma Nação Sob Nossos Pés", category: "books", price: 23.99 },
    { id: 194, name: "Livro do Doutor Estranho: O Juramento", category: "books", price: 22.99 }
    
];

function updatePagination(totalProducts) {
    const paginationContainer = document.getElementById('pagination');
    const totalPages = Math.ceil(totalProducts / productsPerPage);
    paginationContainer.innerHTML = '';

    // Calcular o bloco atual
    const currentBlock = Math.floor((currentPage - 1) / pagesPerBlock);
    const startPage = currentBlock * pagesPerBlock + 1;
    const endPage = Math.min(startPage + pagesPerBlock - 1, totalPages);

    // Botão "Anterior" se não estiver na primeira página
    if (startPage > 1) {
        const prevButton = document.createElement('button');
        prevButton.textContent = 'Anterior';
        prevButton.onclick = () => changeBlock(currentBlock - 1);
        paginationContainer.appendChild(prevButton);
    }

    // Botões de páginas
    for (let i = startPage; i <= endPage; i++) {
        const pageButton = document.createElement('button');
        pageButton.textContent = i;
        pageButton.className = i === currentPage ? 'active' : '';
        pageButton.onclick = () => changePage(i);
        paginationContainer.appendChild(pageButton);
    }

    // Botão "Próximo" se não estiver na última página
    if (endPage < totalPages) {
        const nextButton = document.createElement('button');
        nextButton.textContent = 'Próximo';
        nextButton.onclick = () => changeBlock(currentBlock + 1);
        paginationContainer.appendChild(nextButton);
    }

    const pageIndicator = document.createElement('span');
    pageIndicator.textContent = `Página ${currentPage} de ${totalPages}`;
    paginationContainer.appendChild(pageIndicator);
}

function changePage(pageNumber) {
    currentPage = pageNumber;
    filterProducts(); // Atualiza a lista de produtos conforme a página atual
    updatePagination(totalProducts); // Recalcula a paginação com base no número total de produtos
}

function changeBlock(blockNumber) {
    // Calcula a nova página a partir do bloco selecionado
    const newPage = blockNumber * pagesPerBlock + 1;
    if (newPage >= 1 && newPage <= Math.ceil(totalProducts / productsPerPage)) {
        currentPage = newPage;
        updatePagination(totalProducts);
        filterProducts();
    }
}

const totalProducts = 200;
updatePagination(totalProducts);

// Função para renderizar produtos na página
function renderProducts() {
    // Filtrar e ordenar produtos antes de exibir
    let filteredProducts = products.filter(product => {
        const categoryFilter = document.getElementById('categoryFilter').value;
        return categoryFilter === 'all' || product.category === categoryFilter;
    });

    filteredProducts.sort((a, b) => {
        if (currentSort === 'price') {
            return sortOrder === 'asc' ? a.price - b.price : b.price - a.price;
        } else { // Default to sorting by name
            const comparison = a.name.localeCompare(b.name);
            return sortOrder === 'asc' ? comparison : -comparison;
        }
    });

    // Paginar produtos
    const startIndex = (currentPage - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    const paginatedProducts = filteredProducts.slice(startIndex, endIndex);

    // Renderizar produtos
    const productsContainer = document.getElementById('productsContainer');
    productsContainer.innerHTML = ''; // Limpar produtos anteriores
    paginatedProducts.forEach(product => {
        const productElement = document.createElement('div');
        productElement.classList.add('product');
        productElement.innerHTML = `
            <h2>${product.name}</h2>
            <p>Categoria: ${product.category}</p>
            <p>Preço: R$${product.price.toFixed(2)}</p>
        `;
        productsContainer.appendChild(productElement);
    });

    // Atualizar navegação de páginas
    updatePagination(filteredProducts.length);
}

// Função para atualizar a navegação de páginas
function updatePagination(totalProducts) {
    const totalPages = Math.ceil(totalProducts / productsPerPage);
    const paginationContainer = document.getElementById('pagination');
    paginationContainer.innerHTML = ''; // Limpar navegação anterior

    // Adicionar botão de página anterior
    if (currentPage > 1) {
        const prevButton = document.createElement('button');
        prevButton.textContent = 'Página Anterior';
        prevButton.addEventListener('click', () => updatePage(currentPage - 1));
        paginationContainer.appendChild(prevButton);
    }

    // Adicionar botão de página seguinte
    if (currentPage < totalPages) {
        const nextButton = document.createElement('button');
        nextButton.textContent = 'Próxima Página';
        nextButton.addEventListener('click', () => updatePage(currentPage + 1));
        paginationContainer.appendChild(nextButton);
    }
}

// Função para atualizar a página atual e renderizar produtos
function updatePage(newPage) {
    currentPage = newPage;
    renderProducts();
}

// Função para configurar o critério de ordenação
function setSort(criterion, order) {
    currentSort = criterion;
    sortOrder = order;
    renderProducts();
}

function searchProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const filteredProducts = products.filter(product =>
        product.name.toLowerCase().includes(searchTerm)
    );
    renderProducts(filteredProducts);
}

function searchProducts() {
    const searchTerm = document.getElementById('searchInput').value;
    console.log("Buscando produtos com:", searchTerm);
}

function clearSearch() {
    document.getElementById('searchInput').value = '';
    searchProducts();
}

function filterProducts() {
    renderProducts();
}

function sortProducts() {
    const sortValue = document.getElementById('sortOrder').value;
    let sortCriterion = 'name';
    let sortOrder = 'asc';

    switch (sortValue) {
        case 'nameAsc':
            sortCriterion = 'name';
            sortOrder = 'asc';
            break;
        case 'nameDesc':
            sortCriterion = 'name';
            sortOrder = 'desc';
            break;
        case 'priceAsc':
            sortCriterion = 'price';
            sortOrder = 'asc';
            break;
        case 'priceDesc':
            sortCriterion = 'price';
            sortOrder = 'desc';
            break;
    }

    setSort(sortCriterion, sortOrder);
}

function toggleTheme() {
    const themeStylesheet = document.getElementById('themeStylesheet');
    const currentTheme = themeStylesheet.getAttribute('href');
    if (currentTheme === 'style.css') {
        themeStylesheet.setAttribute('href', 'styledark.css');
        document.getElementById('themeToggleBtn').textContent = 'Modo Claro';
    } else {
        themeStylesheet.setAttribute('href', 'style.css');
        document.getElementById('themeToggleBtn').textContent = 'Modo Escuro';
    }
}

renderProducts();



function filterProducts() {
    const category = document.getElementById('categoryFilter').value;
    let filteredProducts = products;
    
    if (category !== 'all') {
        filteredProducts = products.filter(product => product.category === category);
    }

    displayProducts(filteredProducts);
}

function searchProducts() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    let filteredProducts = products;

    filteredProducts = filteredProducts.filter(p => p.name.toLowerCase().includes(searchTerm));

    displayProducts(filteredProducts);
}

function displayProducts(products) {
    const container = document.getElementById('productsContainer');
    container.innerHTML = '';

    products.forEach(product => {
        const productElement = document.createElement('div');
        productElement.className = 'product-item';
        productElement.innerHTML = `
            <span>${product.name}</span>
            <span>R$${product.price.toFixed(2)}</span>
            <button onclick="addToCart(${product.id})">Adicionar ao Carrinho</button>
        `;
        container.appendChild(productElement);
    });
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
}

displayProducts(products);

let cart = JSON.parse(localStorage.getItem('cart')) || [];

function displayProducts(filteredProducts) {
    const container = document.getElementById('productsContainer');
    container.innerHTML = '';
    
    const startIndex = (currentPage - 1) * productsPerPage;
    const endIndex = startIndex + productsPerPage;
    const paginatedProducts = filteredProducts.slice(startIndex, endIndex);
    
    paginatedProducts.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product-item');
        productDiv.innerHTML = `
            <span>${product.name} - R$${product.price.toFixed(2)}</span>
            <button onclick="addToCart(${product.id})">Adicionar ao Carrinho</button>
        `;
        container.appendChild(productDiv);
    });

    updatePagination(filteredProducts.length);
}

function filterProducts() {
    const category = document.getElementById('categoryFilter').value;
    const filteredProducts = category === 'all' ? products : products.filter(p => p.category === category);
    displayProducts(filteredProducts);
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    cart.push(product);
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCart();
}

function displayCart() {
    const cartContainer = document.getElementById('cartItems');
    cartContainer.innerHTML = '';
    cart.forEach((item, index) => {
        const cartItem = document.createElement('div');
        cartItem.classList.add('cart-item');
        cartItem.innerHTML = `
            <span>${item.name} - R$${item.price.toFixed(2)}</span>
            <button onclick="removeFromCart(${index})">Remover</button>
        `;
        cartContainer.appendChild(cartItem);
    });
}

function removeFromCart(index) {
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    displayCart();
}

function finalizePurchase() {
    if (cart.length === 0) {
        alert('Seu carrinho está vazio!');
    } else {
        localStorage.setItem('cart', JSON.stringify(cart));
        window.location.href = 'checkout.html';
    }
}

function toggleTheme() {
    const themeStylesheet = document.getElementById('themeStylesheet');
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    const themeIcon = document.getElementById('themeIcon');
    
    if (themeStylesheet.getAttribute('href') === 'style.css') {
        themeStylesheet.href = 'styledark.css';
        themeIcon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 8c-8.8 0-16 7.2-16 16v82.5C128.4 128.9 32 240.8 32 384c0 8.8 7.2 16 16 16h81.5c8.8 0 16-7.2 16-16v-82.5C335.6 239.2 432 127.2 432 8c0-8.8-7.2-16-16-16H256z"/></svg>`;
        themeToggleBtn.textContent = 'Modo Claro';
    } else {
        themeStylesheet.href = 'style.css';
        themeIcon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 8c-8.8 0-16 7.2-16 16v82.5C128.4 128.9 32 240.8 32 384c0 8.8 7.2 16 16 16h81.5c8.8 0 16-7.2 16-16v-82.5C335.6 239.2 432 127.2 432 8c0-8.8-7.2-16-16-16H256z"/></svg>`;
        themeToggleBtn.textContent = 'Modo Escuro';
    }
}

function updatePagination(totalProducts) {
    const paginationContainer = document.getElementById('pagination');
    const totalPages = Math.ceil(totalProducts / productsPerPage);
    paginationContainer.innerHTML = '';

    const currentBlock = Math.floor((currentPage - 1) / pagesPerBlock);
    const startPage = currentBlock * pagesPerBlock + 1;
    const endPage = Math.min(startPage + pagesPerBlock - 1, totalPages);

    if (startPage > 1) {
        const prevButton = document.createElement('button');
        prevButton.textContent = 'Anterior';
        prevButton.onclick = () => changeBlock(currentBlock - 1);
        paginationContainer.appendChild(prevButton);
    }

    for (let i = startPage; i <= endPage; i++) {
        const pageButton = document.createElement('button');
        pageButton.textContent = i;
        pageButton.className = i === currentPage ? 'active' : '';
        pageButton.onclick = () => changePage(i);
        paginationContainer.appendChild(pageButton);
    }

    if (endPage < totalPages) {
        const nextButton = document.createElement('button');
        nextButton.textContent = 'Próximo';
        nextButton.onclick = () => changeBlock(currentBlock + 1);
        paginationContainer.appendChild(nextButton);
    }
}

function changePage(pageNumber) {
    currentPage = pageNumber;
    updatePagination(totalProducts); // Recalcula a paginação com base no número total de produtos
    filterProducts(); // Atualiza a lista de produtos conforme a página atual
}

function changeBlock(blockNumber) {
    // Calcula a nova página a partir do bloco selecionado
    const newPage = blockNumber * pagesPerBlock + 1;
    if (newPage >= 1 && newPage <= Math.ceil(totalProducts / productsPerPage)) {
        currentPage = newPage;
        updatePagination(totalProducts);
        filterProducts();
    }
}

displayProducts(products);
displayCart();
