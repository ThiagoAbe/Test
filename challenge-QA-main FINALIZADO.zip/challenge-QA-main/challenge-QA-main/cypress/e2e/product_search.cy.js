describe('Funcionalidades da Loja', () => {
  beforeEach(() => {
    // Visita a página inicial antes de cada teste
    cy.visit('http://localhost'); //Url da Aplicação
  });

  it('Deve listar todos os produtos e verificar a presença dos elementos na tela', () => {
    // Verificar a presença do contêiner de produtos
    cy.get('#productsContainer', { timeout: 10000 }).should('exist');
    
    // Verificar a presença de cada produto
    cy.get('#productsContainer > :nth-child(1)').should('exist'); // Action Figure do Homem-Aranha
    cy.get('#productsContainer > :nth-child(2)').should('exist'); // Funko Pop! Darth Vader
    cy.get('#productsContainer > :nth-child(3)').should('exist'); // Camisa do Star Wars
    cy.get('#productsContainer > :nth-child(4)').should('exist'); // Camiseta do Batman
    cy.get('#productsContainer > :nth-child(5)').should('exist'); // Poster do Harry Potter
    cy.get('#productsContainer > :nth-child(6)').should('exist'); // Caneca do Senhor dos Anéis
    cy.get('#productsContainer > :nth-child(7)').should('exist'); // Luminária do Super Mario
    cy.get('#productsContainer > :nth-child(8)').should('exist'); // Caderno do Star Trek
    cy.get('#productsContainer > :nth-child(9)').should('exist'); // Quebra-Cabeça do Mapa da Terra Média
    cy.get('#productsContainer > :nth-child(10)').should('exist'); // Mouse Pad do League of Legends

    // Verificar a presença dos elementos da interface
    cy.get('h1', { timeout: 10000 }).should('exist'); // Geek QA Gear
    cy.get('#clearSearchBtn', { timeout: 10000 }).should('exist');
    cy.get('#searchInput', { timeout: 10000 }).should('exist');
    cy.get('[onclick="searchProducts()"]', { timeout: 10000 }).should('exist');
    cy.get('#themeToggleBtn', { timeout: 10000 }).should('exist'); // Modo Escuro
    cy.get('#categoryFilter', { timeout: 10000 }).should('exist'); // Campo de seleção de categorias
    cy.get('#sortOrder', { timeout: 10000 }).should('exist'); // Campo de seleção de ordenar por
    cy.get('.cart > h2', { timeout: 10000 }).should('exist'); // Carrinho de Compras
    cy.get('#finalizePurchaseLink', { timeout: 10000 }).should('exist'); // Finalizar Compra
  });

  describe('Funcionalidades do Carrinho de Compras', () => {

    const produtos = [
      { index: 2, nome: 'Funko Pop! Darth Vader' },
      { index: 3, nome: 'Camisa do Star Wars' },
      { index: 4, nome: 'Camiseta do Batman' },
      { index: 5, nome: 'Poster do Harry Potter' },
      { index: 6, nome: 'Caneca do Senhor dos Anéis' },
      { index: 7, nome: 'Luminária do Super Mario' },
      { index: 8, nome: 'Caderno do Star Trek' },
      { index: 9, nome: 'Quebra-Cabeça do Mapa da Terra Média' },
      { index: 10, nome: 'Mouse Pad do League of Legends' }
    ];

    produtos.forEach(produto => {
      it(`Deve adicionar o produto ${produto.nome} ao carrinho e remover do carrinho`, () => {
        // Adicionar o produto ao carrinho
        cy.get(`#productsContainer > :nth-child(${produto.index}) > button`, { timeout: 10000 }).should('exist').click();
        
        // Verificar a presença do carrinho de compras
        cy.get('.cart > h2', { timeout: 10000 }).should('exist');
        
        // Verificar se o botão de remover está presente e clicar
        cy.get('.cart-item > button', { timeout: 10000 }).click();
        
        // Verificar se a URL voltou ao estado inicial
        cy.url().should('eq', 'http://localhost/'); //Url da Aplicação
      });
    });
  });

  describe('Testar Filtros de Categoria', () => {
    beforeEach(() => {
      // Visita a página inicial antes de cada teste
      cy.visit('http://localhost'); // Substitua pela URL da sua aplicação
    });
  
    it('Deve testar cada filtro de categoria disponível e validar a presença dos produtos', () => {
      // Define os filtros possíveis e os produtos esperados para cada filtro
      const filtros = {
        'all': [
          'Action Figure do Homem-Aranha',
          'Funko Pop! Darth Vader',
          'Camisa do Star Wars',
          'Camiseta do Batman',
          'Poster do Harry Potter',
          'Caneca do Senhor dos Anéis',
          'Luminária do Super Mario',
          'Caderno do Star Trek',
          'Quebra-Cabeça do Mapa da Terra Média',
          'Mouse Pad do League of Legends'
        ],
        'clothing': [
          'Camisa do Star Wars',
          'Camiseta do Batman'
        ],
        'decor': [
          'Luminária do Super Mario'
        ],
        'posters': [
          'Poster do Harry Potter'
        ],
        'toys': [
          'Action Figure do Homem-Aranha',
          'Funko Pop! Darth Vader'
        ],
        'bags': [
          // Adicione aqui os produtos que pertencem à categoria 'bags' se houver
        ],
        'puzzles': [
          'Quebra-Cabeça do Mapa da Terra Média'
        ],
        'mugs': [
          'Caneca do Senhor dos Anéis'
        ],
        'accessories': [
          // Adicione aqui os produtos que pertencem à categoria 'accessories' se houver
        ],
        'books': [
          // Adicione aqui os produtos que pertencem à categoria 'books' se houver
        ]
      };
  
      Object.keys(filtros).forEach(filtro => {
        // Seleciona o filtro na lista de categorias
        cy.get('#categoryFilter').select(filtro);
  
        // Verifica o resultado após a seleção do filtro
        cy.get('#productsContainer').should('exist'); // Verificar se o contêiner de produtos está visível
        
        // Verifica a presença dos produtos esperados
        filtros[filtro].forEach(produto => {
          cy.contains(produto).should('be.visible');
        });
  
        
        cy.wait(500); // Aguardar meio segundo
      });
    });
  });
  

  describe('Testar Ordenação de Produtos', () => {
    beforeEach(() => {
      cy.visit('http://localhost');
    });

    it('Deve testar cada opção de ordenação disponível', () => {
      const ordenacoes = [
        'nameAsc',    // Nome (A-Z)
        'nameDesc',   // Nome (Z-A)
        'priceAsc',   // Preço (Menor para Maior)
        'priceDesc'   // Preço (Maior para Menor)
      ];

      ordenacoes.forEach(ordem => {
        cy.get('#sortOrder').select(ordem);

        // Verificar se o contêiner de produtos está visível
        cy.get('#productsContainer', { timeout: 10000 }).should('exist');

        cy.wait(500); // Aguardar meio segundo
      });

      cy.visit('http://localhost');
    });
  });
});